/*
 * Date: 15/11/2018
 * Assessment 3 for PHY2027 module
 */

/*This program reads a data from a text file to create a database and then returns an average mark and grade for each person when requested */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LINES 10
#define NMAX 10
#define NAMEMAX 30
#define DATE 11

// Structure definitions
typedef struct data{
    char firstname[NAMEMAX];
    char surname[NAMEMAX];
    int age;
    float mark[5];
    char title_1[NMAX];
    char title_2[NMAX];
    char date_1[DATE];
    char date_2[DATE];
    char date_3[DATE];
    char date_4[DATE];
    char date_5[DATE];
} Data ;

typedef struct score{
    float average;
    char grade;
}Score;

// Prototype functions
int indata(Data *pdata, FILE *textfile);
void final_mark(Data *pdata, Score *pscore);
int retrieve(Data *pdata, Score *pscore, char name1[NMAX], char name2[NMAX], int *n, int *check);


int main(){
    
    // Defining variables
    int n;
    int check;
    int choice;
    char ch = 0;
    int lines = 0;
    char name1[NMAX];
    char name2[NMAX];
    
    // Openign text file for reading
    FILE *textfile;
    textfile = fopen("assessment3.txt", "r");
    
    // Sanity check
    if (textfile == NULL){
        printf("I cannot open the file\n");
        return -1;
    }
    
    // Counting lines in file to allocate memory
    while(!feof(textfile)){
        ch = fgetc(textfile);
        if(ch == '\n'){
            lines++;
        }
    }
    rewind(textfile);
    
    // Defining pointers and allocating memory
    Data *pdata = NULL;
    pdata = (Data*)malloc((lines)*sizeof(Data));
    
    Score *pscore = NULL;
    pscore = (Score*)malloc((lines-2)*sizeof(Score));
    
    // Calling functions
    indata(pdata, textfile);
    final_mark(pdata, pscore);
    
    
    // Infinite loop to ask the user whether they want a mark/grade returned or to quit the program
    while(1){
        printf("Menu:\n"
               "\t 1. Grade and average mark of a student\n"
               "\t 2. Quit program\n");
        scanf("%d",&choice);
        
        switch(choice) {
                
            // Asking for the name of the student
            case 1:
                printf("Input first name of the student\n");
                scanf("%s", name1);
                printf("Input second name of the student\n");
                scanf("%s", name2);
                
                // Calling function and printing result
                retrieve(pdata, pscore, name1, name2, &n, &check);
                if (check != LINES-2){
                    printf("%s %s got an average of: %.2f and grade: %c\n\n", name1, name2, pscore[n].average, pscore[n].grade);
                    break;
                }
                
            // Quitting program
            case 2:
                printf("Goodbye and thanks for using my program\n");
                return 1;
                
            // Sanity check
            default:
                printf("Unknown action, please try again\n");
                return -1;
        }
    }
    return 0;
}

// Function indata reads data from text file and assigns to struct data
int indata(Data *pdata, FILE *textfile) {
    
    int i=0;
    // Reading titles and dates
    fscanf(textfile, "%s %s %s %s %s %s %s",pdata->title_1, pdata->title_2, pdata->date_1, pdata->date_2, pdata->date_3, pdata->date_4, pdata->date_5);
    // Reading students names and marks
    while (fscanf(textfile, "%s %s %d %f %f %f %f %f", pdata[i].firstname,pdata[i].surname, &pdata[i].age,&pdata[i].mark[0],&pdata[i].mark[1],&pdata[i].mark[2],&pdata[i].mark[3],&pdata[i].mark[4]) != EOF){
        ++i;
    }
    fclose(textfile);
    return 0;
}
// Function final_mark calculates the average mark and grade of each student and stores it in struct score
void final_mark(Data *pdata, Score *pscore){
    
    for (int i=0; i<LINES; ++i){
        pscore[i].average = (pdata[i].mark[0]+pdata[i].mark[1]+pdata[i].mark[2]+pdata[i].mark[3]+pdata[i].mark[4])/5;
        if(pscore[i].average < 40){
            pscore[i].grade = 'E';
        }else if(pscore[i].average < 50){
            pscore[i].grade = 'D';
        }else if(pscore[i].average < 60){
            pscore[i].grade = 'C';
        }else if(pscore[i].average < 70){
            pscore[i].grade = 'B';
        }else{
            pscore[i].grade = 'A';
        }
    }
}
// Function retrieves average and grade from name of the student
int retrieve(Data *pdata, Score *pscore, char name1[NMAX], char name2[NMAX], int *n, int *check){
    
    int c = 0;
    for (int i=0; i<(LINES-2); ++i){
        if (strncmp(name1, pdata[i].firstname, sizeof(&name1)) == 0 && strncmp(name2, pdata[i].surname, sizeof(&name2)) == 0){
            *n = i;
        }
        else{
            c++;
        }
    }
    if (c == LINES-2){
        printf("Student not found, please try again\n");
        *check = c;
        return -1;
    }
    return 0;
    
}

/* Results:
 
 ------------------------------------------------------------------------------------------------------------------------------------
 
 Menu:
 1. Grade and average mark of a student
 2. Quit program
 1
 Input first name of the student
 John
 Input second name of the student
 Doe
 John Doe got an average of: 44.20 and grade: D
 
 ------------------------------------------------------------------------------------------------------------------------------------
 
 Menu:
 1. Grade and average mark of a student
 2. Quit program
 1
 Input first name of the student
 Sandra
 Input second name of the student
 Doe
 Sandra Doe got an average of: 52.20 and grade: C
 
 ------------------------------------------------------------------------------------------------------------------------------------
 
 Menu:
 1. Grade and average mark of a student
 2. Quit program
 1
 Input first name of the student
 Katie
 Input second name of the student
 Doe
 Student not found, please try again
 Goodbye and thanks for using my program
 Program ended with exit code: 1
 
 ------------------------------------------------------------------------------------------------------------------------------------
 
 Menu:
 1. Grade and average mark of a student
 2. Quit program
 2
 Goodbye and thanks for using my program
 Program ended with exit code: 1
 
 ------------------------------------------------------------------------------------------------------------------------------------
 
 Menu:
 1. Grade and average mark of a student
 2. Quit program
 Katie
 Unknown action, please try again
 Program ended with exit code: 255 */
